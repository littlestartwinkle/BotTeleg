# API Token
API_TOKEN = '1380308704:AAEkwaLtQXf9lHdtzgOppCgZpfTbbjlNnPE'

# Admin ID
admin_id = 381881768

   
